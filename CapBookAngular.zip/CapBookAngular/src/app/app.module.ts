import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome/welcome.component';

import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { ViewProfileComponent } from './viewProfile/view-profile.component';
import { FrontPageComponent } from './frontPage/front-page.component';
import { FriendComponent } from './friend/friend.component';
import { PageComponent } from './page/page.component';
import { PostComponent } from './post/post.component';
import { MyProfileComponent } from './myProfile/my-profile.component';
import { ProfilePhotoComponent } from './profilePhoto/profile-photo.component';
import { EditProfileComponent } from './editProfile/edit-profile.component';
import { AccountSettingsComponent } from './accountSettings/account-settings.component';
import { ChangePasswordComponent } from './changePassword/change-password.component';
import { ForgotPasswordComponent } from './forgotPassword/forgot-password.component';
import { FriendsListComponent } from './friend/friendsList/friends-list.component';
import { AuthorizeService } from './AuthorizeService/authorize.service';
import { AddPostComponent } from './post/addPost/add-post.component';
import { AboutComponent } from './about/about.component';
import { PhotosComponent } from './photos/photos.component';
import { FindUsersComponent } from './findUsers/find-users.component';
import { FriendRequestComponent } from './friendRequest/friend-request.component';
import { MessageComponent } from './message/message.component';
import { SentMessagesComponent } from './message/sentMessages/sent-messages.component';
import { RecievedMessagesComponent } from './message/recievedMessages/recieved-messages.component';


@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    LoginComponent,
    RegistrationComponent,
    ViewProfileComponent,
    FrontPageComponent,
    FriendComponent,
    PageComponent,
    PostComponent,
    MyProfileComponent,
    ProfilePhotoComponent,
    EditProfileComponent,
    AccountSettingsComponent,
    ChangePasswordComponent,
    ForgotPasswordComponent,
    FriendsListComponent,
    AddPostComponent,
    AboutComponent,
    PhotosComponent,
    FindUsersComponent,
    FriendRequestComponent,
    MessageComponent,
    SentMessagesComponent,
    RecievedMessagesComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path: 'frontPage',component:FrontPageComponent},
      {path: 'forgotPassword',component:ForgotPasswordComponent,},
      {path: '',redirectTo:'frontPage',pathMatch: 'full'},
      {path: 'myProfile',component:MyProfileComponent,
        children:[
          {path: 'editProfile',component:EditProfileComponent,canActivate:[AuthorizeService]},
          {path: 'post',component:PostComponent,canActivate:[AuthorizeService],
          children:[
            {path: 'addPost',component:AddPostComponent}
        ]},
          {path: 'friendsList',component:FriendsListComponent,canActivate:[AuthorizeService]},
          {path: 'photos',component:PhotosComponent,canActivate:[AuthorizeService]},
          {path: 'message',component:MessageComponent,canActivate:[AuthorizeService],
          children:[
            {path: 'sentMessages',component:SentMessagesComponent},
            {path: 'recievedMessages',component:RecievedMessagesComponent}
        ]},
          {path: 'about',component:AboutComponent,canActivate:[AuthorizeService]},
          {path: 'findUsers/:name',component:FindUsersComponent,
          children:[
            {path: 'friendRequest/:emailId',component:FriendRequestComponent}
        ]},
          {path: 'accountSettings', component:AccountSettingsComponent,
          children:[
            {path: 'changePassword',component:ChangePasswordComponent,canActivate:[AuthorizeService]}
        ],canActivate:[AuthorizeService]}
        ]
        ,canActivate:[AuthorizeService]}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
