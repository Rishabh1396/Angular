import { Component, OnInit } from '@angular/core';
import { Profile } from 'src/app/registration/profile';
import { Message } from '../message';
import { CapbookService } from 'src/app/services/capbook.service';

@Component({
  selector: 'app-sent-messages',
  templateUrl: './sent-messages.component.html',
  styleUrls: ['./sent-messages.component.css']
})
export class SentMessagesComponent implements OnInit {
  profile:Profile
  messageList:Message[]
  constructor(private capBookService:CapbookService) { }

  ngOnInit() {
    this.profile=JSON.parse(localStorage.getItem("currentProfile"))
    console.log(this.profile)
    this.capBookService.getSentMessages(this.profile.emailId).subscribe(
      messageList=>{
        this.messageList=messageList;
        console.log(messageList)
        console.log("in message")
      },
      error=>{
        console.log(error)
      }
    );

}
}
