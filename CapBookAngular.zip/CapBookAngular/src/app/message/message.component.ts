import { Component, OnInit } from '@angular/core';
import { Message } from './message';
import { CapbookService } from '../services/capbook.service';
import { Profile } from '../registration/profile';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit {

  _toEmailId:string='';
  _messageBody:string=''
   profile:Profile;

  constructor(private capBookService: CapbookService) {}

  ngOnInit() {
    this.profile=JSON.parse(localStorage.getItem("currentProfile"))
  }

  set toEmailId(value: string){
    this._toEmailId = value;
  }

  get toEmailId(): string{
    return this._toEmailId;
  }

  set messageBody(value: string){
    this._messageBody = value;
  }

  get messageBody(): string{
    return this._messageBody;
  }

  onSubmitClick(){
    const message:any={
      receiverEmailId:this.toEmailId,
      message:this.messageBody,
      senderEmailId:this.profile.emailId
    }
    this.capBookService.sendMessage(message).subscribe(
      message=>{
        console.log(message)
        console.log("in message")
      },
      error=>{
        console.log(error)
        console.log("in error")
      }
    );

 
  }
}
