export interface Friend {
}
