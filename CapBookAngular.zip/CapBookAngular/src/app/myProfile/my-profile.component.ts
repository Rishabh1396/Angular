import { Component, OnInit } from '@angular/core';
import { Profile } from '../registration/profile';
import { CapbookService } from 'src/app/services/capbook.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {

  currentProfile:Profile;

  fileToUpload:File=null;

  constructor(private route:ActivatedRoute,private router:Router,private capbookService:CapbookService) { 
    this.currentProfile=  JSON.parse(localStorage.getItem("currentProfile"));
  }

  handleFileInput(files:FileList){
    this.fileToUpload=files.item(0);
    this.uploadFileToActivity();
  }

  uploadFileToActivity(){
    console.log("in upload");
    this.capbookService.setProfilePic(this.fileToUpload).subscribe(

      data =>{
        console.log("success")
      },
      error => {
        console.log(error);
    });
  }


  ngOnInit() {

  }
  
  onLogOutClick(){
    localStorage.clear();
    localStorage.setItem("isLoggedIn","false");
    this.router.navigate(['/frontPage']);
  }

}
