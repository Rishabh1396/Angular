import { Component, OnInit } from '@angular/core';
import { Profile } from '../registration/profile';
import { CapbookService } from 'src/app/services/capbook.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Friend } from '../friend/friend';

@Component({
  selector: 'app-friend-request',
  templateUrl: './friend-request.component.html',
  styleUrls: ['./friend-request.component.css']
})
export class FriendRequestComponent implements OnInit {

  currentProfile:Profile;
  friendRequest:Friend;
  message:string;
  eId:string;


  constructor(private route:ActivatedRoute,private router:Router,private capbookService:CapbookService) { 
    this.currentProfile=  JSON.parse(localStorage.getItem("currentProfile"));
  }

  ngOnInit(){
    
    
  }

}
