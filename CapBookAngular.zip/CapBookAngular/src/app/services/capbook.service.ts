import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import {map, catchError} from 'rxjs/operators';
import { Profile } from '../registration/profile';

@Injectable({
  providedIn: 'root'
})
export class CapbookService {

  constructor(private httpClient:HttpClient) { }
  
  public registerUser(profile:any):Observable<Profile>{
    return this.httpClient.post<Profile>("http://localhost:8085/registerUser",profile,{}).
    pipe(catchError(this.handleError));
  }

  public loginUser(userCredentials:any):Observable<Profile>{
   return this.httpClient.post<Profile>("http://localhost:8085/loginUser",userCredentials, {}).
   pipe(catchError(this.handleError));
 }

 public editProfile(profile:any):Observable<Profile>{
  return this.httpClient.post<Profile>("http://localhost:8085/editProfile",profile,{}).
  pipe(catchError(this.handleError));
}

public changePassword(profile:any):Observable<Profile>{
  return this.httpClient.post<Profile>("http://localhost:8085/changePassword",profile,{}).
  pipe(catchError(this.handleError));
}

public forgotPassword(profile:any):Observable<Profile>{
  return this.httpClient.post<Profile>("http://localhost:8085/forgotPassword",profile,{}).
  pipe(catchError(this.handleError));
}

public setProfilePic(fileToUpload:File):any{
  const formData= new FormData();
  formData.append('Image',fileToUpload,fileToUpload.name);
  return this.httpClient.post("http://localhost:8085/setProfilePic",formData).pipe(map(()=>{return true;}),
  catchError(this.handleError));
}

  
private handleError(error:any){
  if(error instanceof ErrorEvent){
    console.error('1 An ErrorEvent occurred:',error.error.message);
    return throwError(error.error.message);
  }else if(error instanceof HttpErrorResponse){
    console.error('2 Backend returned code $(error.status), body was: $(error.message)');
    return throwError('Backend returned code $(error.status), body was: $(error.message)');
  }
  else if(error instanceof TypeError){
    console.error('3 TypeError has occurred $(error.message), body was: $(error.stack)');
    return throwError('TypeError has occurred $(error.message), body was: $(error.stack)');
  }
}
}
