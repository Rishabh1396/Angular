import { Component, OnInit } from '@angular/core';
import { Profile } from '../registration/profile';
import { CapbookService } from 'src/app/services/capbook.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Friend } from '../friend/friend';

@Component({
  selector: 'app-find-users',
  templateUrl: './find-users.component.html',
  styleUrls: ['./find-users.component.css']
})
export class FindUsersComponent implements OnInit {

 /* @Input() */
 profilesList:Profile[];

 currentProfile:Profile;
 friendRequest:Friend;
 message:string;
 eId:string;

 constructor(private route:ActivatedRoute,private router:Router,private capbookService:CapbookService) { 
  this.currentProfile=  JSON.parse(localStorage.getItem("currentProfile"));
 }

 ngOnInit() {
   this.profilesList=JSON.parse(localStorage.getItem("profilesList"))
   console.log("hello")
   console.log(this.profilesList)
 }
 onFriendRequestClick(emailId:string){
    const friendRequest:any={
      toUserId:emailId,
      fromUserId:this.currentProfile.emailId
    }
    this.capbookService.addFriend(friendRequest).subscribe(
      friendRequest=>{
        this.friendRequest = friendRequest;
        this.message='Friend Request Sent!!!'
      },
      error=>{
        this.message='';
      }
    );
 }
}
