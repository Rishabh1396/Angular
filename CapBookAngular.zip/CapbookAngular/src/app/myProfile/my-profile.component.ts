import { Component, OnInit } from '@angular/core';
import { Profile } from 'selenium-webdriver/firefox';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {


  currentProfile:Profile;
  constructor() { 
    this.currentProfile=  JSON.parse(localStorage.getItem("currentProfile"));
  }

  ngOnInit() {

  }

}
