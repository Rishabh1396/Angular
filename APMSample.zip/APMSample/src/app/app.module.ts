import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductListComponent } from './products/product-list.component';
import { ConvertToSpacePipe } from './shared/convert-to-space.pipe';
import { StarComponent } from './shared/star.component';
import {HttpClientModule} from '@angular/common/http';
import { from } from 'rxjs';
import { ProductService } from './services/product.service';
import { WelcomeComponent } from './welcome/welcome.component';
import { RouterModule } from '@angular/router';
import { ProductDetailsComponent } from './products/productDetails/product-details.component';
import { DeleteProductComponent } from './products/delete-product/delete-product.component';
import { AddProductComponent } from './products/add-product/add-product.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    ConvertToSpacePipe,
    StarComponent,
    WelcomeComponent,
    ProductDetailsComponent,
    DeleteProductComponent,
    AddProductComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path: 'products',component:ProductListComponent},
      {path: 'welcome',component:WelcomeComponent},
      {path: '',redirectTo:'welcome',pathMatch: 'full'},
      {path: 'product/:id',component:ProductDetailsComponent},
      {path: 'deleteProduct/:id',component:DeleteProductComponent},
      {path: 'addNewProduct',component:AddProductComponent}
    ])
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
