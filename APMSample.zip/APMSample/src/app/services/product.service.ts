import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Product } from '../products/product';
import {map, catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {


  constructor(private httpClient:HttpClient) { }

 public getAllProductsDetails():Observable<Product[]>{
   return this.httpClient.get<Product[]>("http://localhost:2222/onlineshop/getAllProductDetails").pipe(catchError(this.handleError))
 }
 public getProductDetails(productId:number):Observable<Product>{
   let params = new HttpParams();
   params = params.set('productId',productId.toString());
  return this.httpClient.get<Product>
  ("http://localhost:2222/onlineshop/getProductDetails",{params : params}).
  pipe(catchError(this.handleError));
}

public removeProductDetails(productId:number){
  let params = new HttpParams();
  params = params.set('productId',productId.toString());
  return this.httpClient.delete("http://localhost:2222/onlineshop/removeProductDetails",{params : params}).
  pipe(catchError(this.handleError));
}

public acceptProductDetails(product:any):Observable<void>{
  return this.httpClient.post<void>("http://localhost:2222/onlineshop/acceptProductDetails",product,{}).
  pipe(catchError(this.handleError));
}

private handleError(error:any){
  if(error instanceof ErrorEvent){
    console.error('1 An ErrorEvent occurred:',error.error.message);
    return throwError(error.error.message);
  }else if(error instanceof HttpErrorResponse){
    console.error('2 Backend returned code $(error.status), body was: $(error.message)');
    return throwError('Backend returned code $(error.status), body was: $(error.message)');
  }
  else if(error instanceof TypeError){
    console.error('3 TypeError has occurred $(error.message), body was: $(error.stack)');
    return throwError('TypeError has occurred $(error.message), body was: $(error.stack)');
  }
}
}
