import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  productListTitle:string='Add Product';
  _productId:string='';
  _productCode:string='';
  _productName:string='';
  _releaseDate:string='';
  _description:string='';
  _starRating:string='';

  constructor() { }

  get newProductId(): string{
    return this._productId;
  }
  set newProductId(value: string): {
    this._productId = value;
  }

  get newProductCode(): string{
    return this._productCode;
  }
  set newProductCode(value: string): {
    this._productCode = value;
  }

  get newProductName(): string{
    return this._productId;
  }
  set newProductId(value: string): {
    this._productId = value;
  }

  get newReleaseDate(): string{
    return this._productId;
  }
  set newReleaseDate(value: string): {
    this._productId = value;
  }

  get newProductDescription(): string{
    return this._productId;
  }
  set newProductDescription(value: string): {
    this._productId = value;
  }

  get newProductPrice(): string{
    return this._productId;
  }
  set newProductPrice(value: string): {
    this._productId = value;
  }

  get newProductStarRating(): string{
    return this._productId;
  }
  set newProductStarRating(value: string): {
    this._productId = value;
  }

  ngOnInit() {
  }

}
