import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/product.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../product';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  productListTitle:string='Add Product';
  _productId:number;
  _productCode:string='';
  _productName:string='';
  _releaseDate:string='';
  _description:string='';
  _starRating:number; 
  _productPrice:number;

  error:string;
  message:string;

  constructor(private route:ActivatedRoute,private router:Router,private productService:ProductService) {}

  get newProductId(): number{
    return this._productId;
  }
  set newProductId(value: number) {
    this._productId = value;
  }

  get newProductCode(): string{
    return this._productCode;
  }
  set newProductCode(value: string) {
    this._productCode = value;
  }

  get newProductName(): string{
    return this._productName;
  }
  set newProductName(value: string) {
    this._productName = value;
  }

  get newReleaseDate(): string{
    return this._releaseDate;
  }
  set newReleaseDate(value: string) {
    this._releaseDate = value;
  }

  get newProductDescription(): string{
    return this._description;
  }
  set newProductDescription(value: string) {
    this._description = value;
  }

  get newProductPrice(): number{
    return this._productPrice;
  }
  set newProductPrice(value: number) {
    this._productPrice = value;
  }

  get newProductStarRating(): number{
    return this._starRating;
  }
  set newProductStarRating(value: number) {
    this._starRating = value;
  }

  ngOnInit() {
  }

  onClickSubmit(){
    const product1:any={
    productId:this.newProductId,
    productCode:this.newProductCode,
    price:this.newProductPrice,
    starRating:this.newProductStarRating,
    description:this.newProductDescription,
    productName:this.newProductName,
    releaseDate:this.newReleaseDate
    }
    this.productService.acceptProductDetails(product1).subscribe(
      message=>{
        this.message='Product Added!!';
      },
      error=>{
        this.error=error;
      }
    );
  }

  public navigateBack(){
    this.router.navigate(['/products']);
  }
}
